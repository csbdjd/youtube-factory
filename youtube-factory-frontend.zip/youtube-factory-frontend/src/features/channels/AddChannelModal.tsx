import { useState } from 'react';
import { Modal } from '../../components/Modal';
import { useToast } from '../../components/Toast';
import { newChannel } from '../../data/demo';
import { uid, useStore } from '../../store/AppStore';

export function AddChannelModal({ onClose }: { onClose: () => void }) {
  const { channels, addChannel } = useStore();
  const toast = useToast();
  const [name, setName] = useState('');
  const [theme, setTheme] = useState('');
  const [desc, setDesc] = useState('');

  const create = () => {
    const n = name.trim();
    if (!n) return toast('Вкажіть назву проєкту');
    if (channels.some((c) => c.name.toLowerCase() === n.toLowerCase())) return toast('Проєкт із такою назвою вже існує');
    addChannel(newChannel({ id: uid(), name: n, theme: theme.trim() || 'Без тематики', description: desc.trim() || 'Опис ще не додано.' }));
    toast('Канал додано');
    onClose();
  };

  return (
    <Modal onClose={onClose}>
      <h3 style={{ margin: '0 0 14px', fontSize: 18 }}>Новий канал</h3>
      <div className="fld"><label className="f">Назва проєкту</label><input className="in" value={name} onChange={(e) => setName(e.target.value)} /></div>
      <div className="fld"><label className="f">Тематика</label><input className="in" value={theme} onChange={(e) => setTheme(e.target.value)} /></div>
      <div className="fld"><label className="f">Опис</label><textarea className="in" value={desc} onChange={(e) => setDesc(e.target.value)} /></div>
      <div className="row" style={{ border: 0 }}>
        <div className="grow">
          <div className="t">Google-акаунт не підключено</div>
          <div className="m">1 Google-акаунт = 1 канал = 1 проєкт</div>
        </div>
        <button type="button" className="btn g sm" onClick={() => toast('Google OAuth потребує серверної частини — буде на етапі 3')}>Підключити</button>
      </div>
      <div className="grid g2" style={{ gap: 10, marginTop: 10 }}>
        <button type="button" className="btn g" onClick={onClose}>Скасувати</button>
        <button type="button" className="btn" onClick={create}>Додати канал</button>
      </div>
    </Modal>
  );
}
