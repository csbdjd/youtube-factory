import { useState } from 'react';
import { Modal } from '../../components/Modal';
import { useToast } from '../../components/Toast';
import { Avatar, Section, Switch } from '../../components/ui';
import { DAYS, MAX_SLOTS, sortSlots, validateChannel } from '../../lib/schedule';
import { m2t, t2m } from '../../lib/time';
import { LANGS, TIMEZONES, VOICES, speakTest } from '../../lib/voice';
import { useStore } from '../../store/AppStore';
import type { Channel, Gender } from '../../types';

export function ChannelSettingsModal({ channel, onClose }: { channel: Channel; onClose: () => void }) {
  const { saveChannel } = useStore();
  const toast = useToast();
  // Працюємо з окремою копією: зміни потрапляють у канал лише після «Зберегти».
  const [d, setD] = useState<Channel>(() => JSON.parse(JSON.stringify(channel)) as Channel);
  const [day, setDay] = useState(0);
  const [error, setError] = useState('');
  const set = (p: Partial<Channel>) => setD((x) => ({ ...x, ...p }));
  const setSlots = (fn: (s: string[]) => string[]) =>
    setD((x) => ({ ...x, schedule: x.schedule.map((s, i) => (i === day ? fn(s) : s)) }));
  const slots = d.schedule[day];
  const tzAuto = Intl.DateTimeFormat().resolvedOptions().timeZone;

  const addSlot = () => {
    if (slots.length >= MAX_SLOTS) return toast(`Максимум ${MAX_SLOTS} публікацій на день`);
    const last = slots.length ? Math.max(...slots.map(t2m)) : 360;
    setSlots((s) => [...s, m2t(last + 180)]);
  };
  const setGender = (g: Gender) => {
    const names = VOICES.filter((v) => v[1] === g).map((v) => v[0]);
    set({ voiceGender: g, voiceName: names.includes(d.voiceName) ? d.voiceName : names[0] });
  };
  const save = () => {
    const e = validateChannel(d);
    if (e) {
      setError(e);
      toast('Перевірте налаштування');
      return;
    }
    saveChannel(sortSlots(d));
    toast('Налаштування каналу збережено');
    onClose();
  };

  return (
    <Modal onClose={onClose} wide>
      <div className="ttl" style={{ marginBottom: 12 }}>
        <h3 style={{ margin: 0, fontSize: 18 }}>Налаштування: {d.name}</h3>
        <button type="button" className="btn g sm" onClick={onClose} aria-label="Закрити">✕</button>
      </div>
      {error && <div className="ce">⚠ {error}</div>}

      <Section title="Проєкт і Google-акаунт">
        <div className="fld">
          <label className="f">Назва проєкту</label>
          <input className="in" value={d.name} onChange={(e) => set({ name: e.target.value })} />
        </div>
        <div className="row" style={{ border: 0 }}>
          {d.googleId && <Avatar channel={d} size={44} />}
          <div className="grow">
            <div className="t">{d.googleId ? `Підключено: ${d.googleName}` : 'Google-акаунт не підключено'}</div>
            <div className="m">{d.googleId ? `ID каналу: ${d.googleId}` : '1 Google-акаунт = 1 канал = 1 проєкт'}</div>
          </div>
          {d.googleId ? (
            <button type="button" className="btn g sm" onClick={() => set({ googleId: null, googleName: '' })}>Від’єднати</button>
          ) : (
            <button type="button" className="btn sm" onClick={() => toast('Google OAuth потребує серверної частини — буде на етапі 3')}>Підключити Google</button>
          )}
        </div>
      </Section>

      <Section title="Публікація">
        <div className="row" style={{ border: 0, paddingTop: 0 }}>
          <div className="grow">
            <div className="t">Автоматична публікація</div>
            <div className="m">Планувальник бере розклад саме цього каналу</div>
          </div>
          <Switch on={d.autoPublish} label="Автоматична публікація" onChange={() => set({ autoPublish: !d.autoPublish })} />
        </div>
        <div className="fld">
          <label className="f">Часовий пояс</label>
          <select className="in" value={d.timezone} onChange={(e) => set({ timezone: e.target.value })}>
            <option value="auto">Автоматично ({tzAuto})</option>
            {TIMEZONES.map((z) => <option key={z} value={z}>{z}</option>)}
          </select>
        </div>
        <label className="f">Дні публікації</label>
        <div className="chips">
          {DAYS.map((n, k) => (
            <span key={n} className={'chip' + (d.days[k] ? ' on' : '')}
              onClick={() => set({ days: d.days.map((v, i) => (i === k ? !v : v)) })}>{n}</span>
          ))}
        </div>
      </Section>

      <Section title="Розклад публікацій">
        <div className="chips" style={{ marginBottom: 12 }}>
          {DAYS.map((n, k) => (
            <span key={n} className={'chip' + (k === day ? ' on' : '')} style={d.days[k] ? undefined : { opacity: 0.5 }}
              onClick={() => setDay(k)}>{n} · {d.schedule[k].length}</span>
          ))}
        </div>
        <div className="ttl" style={{ marginBottom: 8 }}>
          <span className="stp">
            <span className="m">Відео на день ({DAYS[day]})</span>
            <button type="button" className="btn g sm" onClick={() => setSlots((s) => s.slice(0, -1))}>−</button>
            <b>{slots.length}</b>
            <button type="button" className="btn g sm" onClick={addSlot}>＋</button>
          </span>
          <span style={{ display: 'flex', gap: 8 }}>
            <button type="button" className="btn sm" onClick={addSlot}>Додати час</button>
            <button type="button" className="btn g sm"
              onClick={() => { set({ schedule: d.schedule.map(() => [...slots]) }); toast('Розклад скопійовано на всі дні'); }}>На всі дні</button>
          </span>
        </div>
        {slots.length === 0 && <div className="m">На цей день публікацій немає.</div>}
        {slots.map((t, k) => (
          <div className="row" key={k}>
            <span className="m" style={{ width: 72 }}>Відео №{k + 1}</span>
            <input className="in" type="time" value={t} style={{ maxWidth: 150 }}
              onChange={(e) => setSlots((s) => s.map((x, i) => (i === k ? e.target.value : x)))} />
            <span className="grow" />
            <button type="button" className="btn g sm" onClick={() => setSlots((s) => s.filter((_, i) => i !== k))}>Видалити</button>
          </div>
        ))}
        <div className="m" style={{ marginTop: 8 }}>Кількість відео на день = кількість часів у розкладі.</div>
      </Section>

      <Section title="Тривалість відео">
        <div className="grid g3" style={{ gap: 10 }}>
          {([['Мінімум, хв', 'durationMin'], ['Бажана, хв', 'durationPref'], ['Максимум, хв', 'durationMax']] as const).map(([label, key]) => (
            <div key={key}>
              <label className="f">{label}</label>
              <input className="in" type="number" min={1} value={d[key]} onChange={(e) => set({ [key]: Number(e.target.value) })} />
            </div>
          ))}
        </div>
      </Section>

      <Section title="Голос та озвучення">
        <label className="f">Стать голосу</label>
        <div className="chips" style={{ marginBottom: 12 }}>
          <span className={'chip' + (d.voiceGender === 'f' ? ' on' : '')} onClick={() => setGender('f')}>Жіночий</span>
          <span className={'chip' + (d.voiceGender === 'm' ? ' on' : '')} onClick={() => setGender('m')}>Чоловічий</span>
        </div>
        <div className="grid g2" style={{ gap: 10 }}>
          <div className="fld">
            <label className="f">AI-голос</label>
            <select className="in" value={d.voiceName} onChange={(e) => set({ voiceName: e.target.value })}>
              {VOICES.filter((v) => v[1] === d.voiceGender).map((v) => <option key={v[0]}>{v[0]}</option>)}
            </select>
          </div>
          <div className="fld">
            <label className="f">Мова озвучення</label>
            <select className="in" value={d.voiceLang} onChange={(e) => set({ voiceLang: e.target.value })}>
              {LANGS.map((l) => <option key={l[0]} value={l[0]}>{l[1]}</option>)}
            </select>
          </div>
        </div>
        <label className="f">Швидкість: <b>{d.voiceSpeed.toFixed(2)}×</b></label>
        <input type="range" min={0.7} max={1.3} step={0.05} value={d.voiceSpeed} onChange={(e) => set({ voiceSpeed: Number(e.target.value) })} />
        <label className="f" style={{ marginTop: 12 }}>Гучність: <b>{d.voiceVolume}%</b></label>
        <input type="range" min={0} max={100} value={d.voiceVolume} onChange={(e) => set({ voiceVolume: Number(e.target.value) })} />
        <button type="button" className="btn g sm" style={{ marginTop: 12 }}
          onClick={() => { if (!speakTest(d.voiceLang, d.voiceSpeed, d.voiceVolume)) toast('Браузер не підтримує тест голосу'); }}>▶ Прослухати тест</button>
        <div className="m" style={{ marginTop: 6 }}>Тест звучить голосом вашого браузера; справжні AI-голоси з’являться після підключення провайдера.</div>
      </Section>

      <div className="grid g2" style={{ gap: 10 }}>
        <button type="button" className="btn g" onClick={onClose}>Скасувати</button>
        <button type="button" className="btn" onClick={save}>Зберегти налаштування</button>
      </div>
    </Modal>
  );
}
