import { dailyCount, nextPublication } from '../../lib/schedule';
import { useNav } from '../../router';
import { useStore } from '../../store/AppStore';
import { Avatar, Pill, Switch } from '../../components/ui';
import { useToast } from '../../components/Toast';

/** Широка таблиця каналів для великих екранів (на телефоні прихована стилями .dko). */
export function ChannelsTable() {
  const { channels, toggleAuto } = useStore();
  const go = useNav();
  const toast = useToast();
  return (
    <div className="card dko" style={{ marginTop: 14 }}>
      <h3>
        Мої канали
        <a className="m" style={{ cursor: 'pointer' }} onClick={() => go('channels')}>Керувати каналами</a>
      </h3>
      <div className="tw">
        <table className="ct">
          <thead>
            <tr>
              <th>Канал</th><th className="hx">Тематика</th><th>Підписники</th><th className="hx">Перегляди/міс</th>
              <th className="hx">Відео</th><th>Зростання</th><th className="hx">Розклад</th><th>Статус</th><th />
            </tr>
          </thead>
          <tbody>
            {channels.map((c) => (
              <tr key={c.id}>
                <td><div style={{ display: 'flex', alignItems: 'center', gap: 10 }}><Avatar channel={c} size={36} /><b>{c.name}</b></div></td>
                <td className="hx">{c.theme}</td>
                <td>{c.subscribers}</td>
                <td className="hx">{c.monthlyViews}</td>
                <td className="hx">{c.videos}</td>
                <td style={{ color: 'var(--ok)', fontWeight: 700 }}>{c.growth}</td>
                <td className="hx">{dailyCount(c)}/день · {nextPublication(c)}</td>
                <td>{c.autoPublish ? <Pill tone="ok">Активний</Pill> : <Pill>Пауза</Pill>}</td>
                <td>
                  <Switch on={c.autoPublish} label={`Автопублікація: ${c.name}`}
                    onChange={() => toast(toggleAuto(c.id) ? 'Автоматизацію увімкнено' : 'Автоматизацію призупинено')} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
