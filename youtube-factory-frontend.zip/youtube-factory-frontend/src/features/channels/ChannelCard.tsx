import { dailyCount, nextPublication } from '../../lib/schedule';
import { useStore } from '../../store/AppStore';
import type { Channel } from '../../types';
import { Avatar, Switch } from '../../components/ui';
import { useToast } from '../../components/Toast';

export function ChannelCard({ channel: c, onConfigure }: { channel: Channel; onConfigure: () => void }) {
  const { toggleAuto } = useStore();
  const toast = useToast();
  const tiles: Array<[string, string]> = [
    ['Відео на день', dailyCount(c)],
    ['Найближча публікація', nextPublication(c)],
    ['Тривалість', `${c.durationPref} хв (${c.durationMin}–${c.durationMax})`],
    ['Голос', `${c.voiceName} · ${c.voiceGender === 'm' ? 'чол.' : 'жін.'} · ${c.voiceLang.toUpperCase()}`],
  ];
  return (
    <div className="card">
      <div className="row" style={{ border: 0, paddingTop: 0 }}>
        <Avatar channel={c} size={52} />
        <div className="grow">
          <div className="t" style={{ fontSize: 16 }}>{c.name}</div>
          <div className="m">
            {c.googleId
              ? <><span style={{ color: 'var(--ok)' }}>● Підключено</span> · {c.googleName}</>
              : <><span style={{ color: 'var(--wn)' }}>● Не підключено</span> · {c.theme}</>}
          </div>
        </div>
        <Switch on={c.autoPublish} label={`Автопублікація: ${c.name}`}
          onChange={() => toast(toggleAuto(c.id) ? 'Автоматизацію увімкнено' : 'Автоматизацію призупинено')} />
      </div>
      <div className="grid" style={{ gridTemplateColumns: '1fr 1fr', gap: 8, margin: '12px 0' }}>
        {tiles.map(([label, value]) => (
          <div key={label} style={{ background: 'var(--p2)', borderRadius: 12, padding: 10, minWidth: 0 }}>
            <div className="m">{label}</div>
            <div style={{ fontWeight: 700, fontSize: 13 }}>{value}</div>
          </div>
        ))}
      </div>
      <div className="ttl">
        <span className="m">{c.subscribers} підписників · {c.growth}</span>
        <button type="button" className="btn sm" onClick={onConfigure}>Налаштувати канал</button>
      </div>
    </div>
  );
}
