import { useState } from 'react';
import { AddChannelModal } from '../features/channels/AddChannelModal';
import { ChannelCard } from '../features/channels/ChannelCard';
import { ChannelSettingsModal } from '../features/channels/ChannelSettingsModal';
import { Icon, PageHead } from '../components/ui';
import { useStore } from '../store/AppStore';

export default function Channels() {
  const { channels } = useStore();
  const [editId, setEditId] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);
  const editing = channels.find((c) => c.id === editId);
  return (
    <>
      <PageHead title="Мої канали" sub="Кожен канал — окремий проєкт із власними налаштуваннями"
        right={<button type="button" className="btn sm" onClick={() => setAdding(true)}><Icon name="plus" />Додати канал</button>} />
      <div className="grid gch">
        {channels.map((c) => <ChannelCard key={c.id} channel={c} onConfigure={() => setEditId(c.id)} />)}
      </div>
      {editing && <ChannelSettingsModal key={editing.id} channel={editing} onClose={() => setEditId(null)} />}
      {adding && <AddChannelModal onClose={() => setAdding(false)} />}
    </>
  );
}
