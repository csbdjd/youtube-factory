import { ChannelsTable } from '../features/channels/ChannelsTable';
import { QueueItem } from '../components/QueueItem';
import { Avatar, Icon, PageHead, Pill } from '../components/ui';
import { PRODUCTION_14D } from '../data/demo';
import { DAYS } from '../lib/schedule';
import { costOf, money } from '../lib/format';
import { useNav } from '../router';
import { useStore } from '../store/AppStore';

const AI_SERVICES = ['Сценарії (LLM)', 'Зображення', 'Озвучка (TTS)', 'Відео та монтаж'];

function ProductionChart() {
  const today = new Date();
  const { created, published } = PRODUCTION_14D;
  return (
    <div className="card dko" style={{ marginBottom: 14 }}>
      <h3>Графік виробництва<Pill>Демо-дані · 14 днів</Pill></h3>
      <div className="ttl" style={{ marginBottom: 10 }}>
        <span className="m"><span className="dot" style={{ background: 'var(--red)', boxShadow: 'none' }} />Створено</span>
        <span className="m"><span className="dot" style={{ background: 'var(--vi)', boxShadow: 'none' }} />Опубліковано</span>
      </div>
      <div className="chart" style={{ height: 200, gap: 10 }}>
        {created.map((v, i) => {
          const d = new Date(today.getFullYear(), today.getMonth(), today.getDate() - (13 - i));
          const label = `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}`;
          return (
            <div key={label}>
              <div style={{ flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'center', gap: 3, width: '100%', height: 170, flex: 'none' }}>
                <i style={{ height: v * 18 }} />
                <i style={{ height: published[i] * 18, background: 'linear-gradient(180deg,#a78bfa,var(--vi))' }} />
              </div>
              <span>{label}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function AiMonitoringPlaceholder() {
  return (
    <div className="card mon dko">
      <h3>Моніторинг AI-сервісів<Pill>Не підключено</Pill></h3>
      {AI_SERVICES.map((s) => (
        <div className="row" key={s}>
          <div className="grow"><div className="t">{s}</div><div className="m">Провайдер ще не обрано</div></div>
          <span className="m">—</span>
        </div>
      ))}
      <div className="m" style={{ marginTop: 10 }}>Тут з’являтимуться статус, затримка та ліміти кожного AI-API після підключення.</div>
    </div>
  );
}

export default function Home() {
  const { channels, jobs, costs } = useStore();
  const go = useNav();
  const inWork = jobs.filter((j) => j.status === 'run' || j.status === 'wait').length;
  const total = costs.reduce((a, v) => a + costOf(v), 0);
  const stats: Array<[string, string | number, string]> = [
    ['Канали', channels.length, '+1'],
    ['Створено відео', 148, '+12 за тиждень'],
    ['В обробці', inWork, 'зараз'],
    ['Опубліковано', 131, '+9%'],
    ['Загальні витрати', money(total), 'цього місяця'],
    ['Сервер', 'Онлайн', 'CPU 23%'],
  ];
  const week = [3, 5, 4, 6, 5, 7, 6];
  return (
    <>
      <PageHead title="Головна панель" sub="Огляд виробництва за сьогодні"
        right={<span className="pill ok"><span className="dot" style={{ margin: 0 }} />Сервер онлайн</span>} />
      <div className="grid g6">
        {stats.map(([label, value, delta]) => (
          <div className="card stat" key={label}><div className="l">{label}</div><div className="v">{value}</div><div className="d">{delta}</div></div>
        ))}
      </div>
      <div className="card hero">
        <div>
          <h2>Готові створити нове відео?</h2>
          <p>Оберіть канал і тему — або дозвольте системі знайти трендову тему автоматично.</p>
          <button type="button" className="btn" onClick={() => go('create')}><Icon name="bolt" />Запустити створення</button>
        </div>
        <div className="play"><i /></div>
      </div>
      <ProductionChart />
      <div className="grid g2">
        <div className="card">
          <h3>Черга виробництва<a className="m" style={{ cursor: 'pointer' }} onClick={() => go('queue')}>Уся черга</a></h3>
          {jobs.slice(0, 3).map((j) => <QueueItem key={j.id} job={j} />)}
        </div>
        <div className="grid">
          <AiMonitoringPlaceholder />
          <div className="card mbo">
            <h3>Відео за 7 днів</h3>
            <div className="chart">
              {week.map((d, i) => <div key={i}><span>{d}</span><i style={{ height: d * 12 }} /><span>{DAYS[i]}</span></div>)}
            </div>
          </div>
          <div className="card mbo">
            <h3>Мої канали<a className="m" style={{ cursor: 'pointer' }} onClick={() => go('channels')}>Усі</a></h3>
            {channels.map((c) => (
              <div className="row" key={c.id}>
                <Avatar channel={c} size={38} />
                <div className="grow"><div className="t">{c.name}</div><div className="m">{c.subscribers} підписників · {c.growth}</div></div>
                {c.autoPublish ? <Pill tone="ok">Активний</Pill> : <Pill>Пауза</Pill>}
              </div>
            ))}
          </div>
        </div>
      </div>
      <ChannelsTable />
    </>
  );
}
