import { useState } from 'react';
import { PageHead, Pill, Switch, Icon } from '../components/ui';
import { useToast } from '../components/Toast';
import { money } from '../lib/format';
import { useNav } from '../router';
import { useStore } from '../store/AppStore';

type StepKey = 'script' | 'images' | 'voice' | 'ffmpeg' | 'subtitles' | 'music';
const STEPS: ReadonlyArray<{ key: StepKey; title: string; sub: string }> = [
  { key: 'script', title: 'Генерація сценарію', sub: 'Текст і структура відео' },
  { key: 'images', title: 'Генерація зображень', sub: 'Кадри для кожної сцени' },
  { key: 'voice', title: 'AI-озвучка', sub: 'Голос диктора' },
  { key: 'ffmpeg', title: 'Монтаж через FFmpeg', sub: 'Автоматичне складання відео' },
  { key: 'subtitles', title: 'Субтитри', sub: 'Автоматичні, українською' },
  { key: 'music', title: 'Фонова музика', sub: 'Тиха підкладка під голос' },
];
const DURATIONS = ['1–3 хв', '3–5 хв', '8–10 хв', '12–15 хв'];

export default function Create() {
  const { channels, addJob } = useStore();
  const go = useNav();
  const toast = useToast();
  const [channelId, setChannelId] = useState(channels[0]?.id ?? '');
  const [topic, setTopic] = useState('');
  const [duration, setDuration] = useState('8–10 хв');
  const [opts, setOpts] = useState<Record<StepKey, boolean>>({ script: true, images: true, voice: true, ffmpeg: true, subtitles: true, music: true });
  const cost = 0.03 * Number(opts.script) + 0.65 * Number(opts.images) + 0.4 * Number(opts.voice);

  const submit = () => {
    if (!channelId) return toast('Спочатку додайте канал');
    if (!topic.trim()) return toast('Спочатку введіть тему відео');
    addJob(topic.trim(), channelId);
    setTopic('');
    toast('Відео додано в чергу');
    go('queue');
  };

  return (
    <>
      <PageHead title="Створення відео" sub="Налаштуйте виробництво та запустіть процес" right={<Pill tone="wn">Демо-режим</Pill>} />
      <div className="grid g2">
        <div className="card">
          <div className="fld">
            <label className="f">Канал</label>
            <select className="in" value={channelId} onChange={(e) => setChannelId(e.target.value)}>
              {channels.map((c) => <option key={c.id} value={c.id}>{c.emoji} {c.name}</option>)}
            </select>
          </div>
          <div className="fld">
            <label className="f">Тема відео</label>
            <textarea className="in" placeholder="Наприклад: 10 неймовірних фактів про котів" value={topic} onChange={(e) => setTopic(e.target.value)} />
          </div>
          <div className="fld">
            <label className="f">Тривалість</label>
            <div className="chips">
              {DURATIONS.map((d) => <span key={d} className={'chip' + (d === duration ? ' on' : '')} onClick={() => setDuration(d)}>{d}</span>)}
            </div>
          </div>
          <label className="f">Етапи виробництва</label>
          {STEPS.map((s) => (
            <div className="row" key={s.key}>
              <div className="grow"><div className="t">{s.title}</div><div className="m">{s.sub}</div></div>
              <Switch on={opts[s.key]} label={s.title} onChange={() => setOpts({ ...opts, [s.key]: !opts[s.key] })} />
            </div>
          ))}
          <div className="fld" style={{ marginTop: 12 }}>
            <label className="f">AI-провайдер (єдиний інтерфейс, підключається пізніше)</label>
            <select className="in" defaultValue="demo">
              <option value="demo">Демо-провайдер (без витрат)</option>
              <option disabled>＋ Додати провайдера — на наступному етапі</option>
            </select>
          </div>
        </div>
        <div className="grid" style={{ alignContent: 'start' }}>
          <div className="card">
            <h3>Попередній перегляд<Pill>{duration}</Pill></h3>
            <div className="pv">
              <div className="pt"><i /></div>
              {opts.subtitles && <div className="sb">{topic || 'Тут з’являться субтитри'}</div>}
            </div>
            <div className="m" style={{ marginTop: 10 }}>Макет показує, як виглядатиме відео. Реальний кадр буде після підключення генерації.</div>
          </div>
          <div className="card">
            <h3>Орієнтовна вартість<b>{money(cost)}</b></h3>
            <button type="button" className="btn" style={{ width: '100%' }} onClick={submit}><Icon name="bolt" />Додати в чергу</button>
          </div>
        </div>
      </div>
    </>
  );
}
