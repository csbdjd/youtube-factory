import { PageHead, Pill } from '../components/ui';
import { QueueItem } from '../components/QueueItem';
import { useStore } from '../store/AppStore';

export default function Queue() {
  const { jobs } = useStore();
  const running = jobs.filter((j) => j.status === 'run').length;
  return (
    <>
      <PageHead title="Черга виробництва" sub="Поточні етапи, помилки та повторний запуск" right={<Pill tone="bl">Активних: {running}</Pill>} />
      <div className="card">{jobs.map((j) => <QueueItem key={j.id} job={j} full />)}</div>
    </>
  );
}
