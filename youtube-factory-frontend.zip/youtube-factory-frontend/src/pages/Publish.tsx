import { useState } from 'react';
import { PageHead, Switch } from '../components/ui';
import { useToast } from '../components/Toast';

const COVERS = ['#243b6b,#ff6a3a', '#7a1f3d,#f59e0b', '#14532d,#06b6d4'];

/** Значення для datetime-local: завтра о 18:00 за локальним часом. */
function defaultSlot(): string {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T18:00`;
}

export default function Publish() {
  const toast = useToast();
  const [title, setTitle] = useState('10 неймовірних фактів про котів');
  const [desc, setDesc] = useState('У цьому відео ви дізнаєтесь про найдивовижніші факти про котів.');
  const [tags, setTags] = useState<string[]>(['коти', 'факти', 'цікаво']);
  const [tagInput, setTagInput] = useState('');
  const [cover, setCover] = useState(0);
  const [auto, setAuto] = useState(true);
  const [when, setWhen] = useState(defaultSlot);

  return (
    <>
      <PageHead title="Публікація" sub="Підготовка відео до виходу на YouTube" />
      <div className="grid g2">
        <div className="card">
          <div className="row" style={{ border: 0, paddingTop: 0 }}>
            <div className="av" style={{ background: '#ff2d2d22', color: 'var(--red)' }}>▶</div>
            <div className="grow"><div className="t">YouTube</div><div className="m">Акаунт не підключено</div></div>
            <button type="button" className="btn sm" onClick={() => toast('Підключення YouTube з’явиться на етапі API')}>Підключити</button>
          </div>
          <div className="fld"><label className="f">Назва</label><input className="in" value={title} onChange={(e) => setTitle(e.target.value)} /></div>
          <div className="fld"><label className="f">Опис</label><textarea className="in" value={desc} onChange={(e) => setDesc(e.target.value)} /></div>
          <div className="fld">
            <label className="f">Теги</label>
            <div className="chips">
              {tags.map((t) => <span key={t} className="chip" onClick={() => setTags(tags.filter((x) => x !== t))}>#{t} ✕</span>)}
            </div>
            <input className="in" style={{ marginTop: 8 }} placeholder="Додати тег і натиснути Enter" value={tagInput}
              onChange={(e) => setTagInput(e.target.value)}
              onKeyDown={(e) => {
                const v = tagInput.trim();
                if (e.key === 'Enter' && v && !tags.includes(v)) { setTags([...tags, v]); setTagInput(''); }
              }} />
          </div>
        </div>
        <div className="card">
          <label className="f">Обкладинка</label>
          <div className="grid g3" style={{ gap: 8, marginBottom: 16 }}>
            {COVERS.map((g, i) => (
              <div key={g} onClick={() => setCover(i)}
                style={{ aspectRatio: '16/9', borderRadius: 10, background: `linear-gradient(135deg,${g})`, cursor: 'pointer', border: `2px solid ${cover === i ? 'var(--red)' : 'transparent'}` }} />
            ))}
          </div>
          <div className="fld"><label className="f">Дата й час публікації</label><input className="in" type="datetime-local" value={when} onChange={(e) => setWhen(e.target.value)} /></div>
          <div className="row">
            <div className="grow"><div className="t">Автоматична публікація</div><div className="m">Публікувати без підтвердження</div></div>
            <Switch on={auto} label="Автоматична публікація" onChange={() => setAuto(!auto)} />
          </div>
          <button type="button" className="btn" style={{ width: '100%', marginTop: 14 }}
            onClick={() => toast('Заплановано (демо): YouTube ще не підключено')}>Запланувати публікацію</button>
        </div>
      </div>
    </>
  );
}
