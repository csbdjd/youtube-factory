import { PageHead } from '../components/ui';
import { costOf, money } from '../lib/format';
import { useStore } from '../store/AppStore';

export default function Finance() {
  const { channels, costs } = useStore();
  const total = costs.reduce((a, v) => a + costOf(v), 0);
  const sum = (k: 'script' | 'image' | 'voice') => costs.reduce((a, v) => a + v[k], 0);
  const cards: Array<[string, string]> = [
    ['Усього витрат', money(total)], ['Озвучка', money(sum('voice'))], ['Зображення', money(sum('image'))],
    ['Середнє за відео', money(costs.length ? total / costs.length : 0)],
  ];
  const nameOf = (id: string) => channels.find((c) => c.id === id)?.name ?? '—';
  return (
    <>
      <PageHead title="Фінанси" sub="Витрати на відео та канали (демонстраційні дані)" />
      <div className="grid g4" style={{ marginBottom: 14 }}>
        {cards.map(([label, value]) => <div className="card stat" key={label}><div className="l">{label}</div><div className="v">{value}</div></div>)}
      </div>
      <div className="grid g2">
        <div className="card">
          <h3>Витрати по каналах</h3>
          {channels.map((c) => {
            const s = costs.filter((v) => v.channelId === c.id).reduce((a, v) => a + costOf(v), 0);
            return (
              <div key={c.id} style={{ marginBottom: 12 }}>
                <div className="ttl"><span className="t">{c.emoji} {c.name}</span><b>{money(s)}</b></div>
                <div className="bar" style={{ marginTop: 6 }}><i style={{ width: `${total ? Math.min(100, (s / total) * 250) : 0}%` }} /></div>
              </div>
            );
          })}
        </div>
        <div className="card">
          <h3>Витрати на кожне відео</h3>
          <div className="tw">
            <table>
              <thead><tr><th>Відео</th><th>Канал</th><th>Сценарій</th><th>Зображення</th><th>Озвучка</th><th>Разом</th></tr></thead>
              <tbody>
                {costs.map((v) => (
                  <tr key={v.title}>
                    <td>{v.title}</td><td>{nameOf(v.channelId)}</td><td>{money(v.script)}</td><td>{money(v.image)}</td>
                    <td>{money(v.voice)}</td><td><b>{money(costOf(v))}</b></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  );
}
