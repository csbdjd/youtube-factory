import type { ComponentType } from 'react';
import { BottomNav, Sidebar } from './components/Layout';
import { ToastProvider } from './components/Toast';
import { NavProvider, useRoute } from './router';
import Channels from './pages/Channels';
import Create from './pages/Create';
import Finance from './pages/Finance';
import Home from './pages/Home';
import Publish from './pages/Publish';
import Queue from './pages/Queue';
import { StoreProvider } from './store/AppStore';
import type { Route } from './types';

const PAGES: Record<Route, ComponentType> = {
  home: Home, channels: Channels, create: Create, queue: Queue, publish: Publish, finance: Finance,
};

function Shell() {
  const Page = PAGES[useRoute()];
  return (
    <>
      <div className="app">
        <Sidebar />
        <main id="mn"><Page /></main>
      </div>
      <BottomNav />
    </>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <StoreProvider>
        <NavProvider>
          <Shell />
        </NavProvider>
      </StoreProvider>
    </ToastProvider>
  );
}
