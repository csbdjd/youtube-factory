export const f2 = (n: number): string => String(n).padStart(2, '0');

export function m2t(minutes: number): string {
  const x = Math.max(0, Math.min(1439, Math.round(minutes)));
  return `${f2(Math.floor(x / 60))}:${f2(x % 60)}`;
}

/** "HH:MM" -> хвилини від початку доби; -1 для некоректного значення. */
export function t2m(t: string): number {
  const m = /^(\d\d):(\d\d)$/.exec(t);
  if (!m) return -1;
  const h = Number(m[1]);
  const mi = Number(m[2]);
  return h < 24 && mi < 60 ? h * 60 + mi : -1;
}
