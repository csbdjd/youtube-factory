import { describe, expect, it } from 'vitest';
import type { Job } from '../types.ts';
import { stageOf, tick } from './queue.ts';

const job = (id: string, status: Job['status'], progress = 0): Job => ({ id, title: id, channelId: 'c1', progress, status });

describe('черга (демо-симуляція)', () => {
  it('просуває виконувані завдання й завершує на 100%', () => {
    const r = tick([job('a', 'run', 98)], () => 0.99);
    expect(r[0].status).toBe('done');
    expect(r[0].progress).toBe(100);
  });
  it('запускає наступне очікуюче, коли нічого не виконується', () => {
    const r = tick([job('a', 'done', 100), job('b', 'wait')], () => 0.5);
    expect(r[1].status).toBe('run');
  });
  it('помилкові завдання не чіпає', () => {
    const r = tick([job('e', 'err', 40)], () => 0.5);
    expect(r[0]).toEqual(job('e', 'err', 40));
  });
  it('stageOf', () => {
    expect(stageOf(0)).toBe('Сценарій');
    expect(stageOf(100)).toBe('Завершено');
  });
});
