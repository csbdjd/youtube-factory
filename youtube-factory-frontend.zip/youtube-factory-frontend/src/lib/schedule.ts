import type { Channel } from '../types.ts';
import { m2t, t2m } from './time.ts';

export const DAYS = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Нд'] as const;
export const MAX_SLOTS = 12;
export const MIN_GAP_MIN = 30;

/** Рівномірно розподіляє n слотів, починаючи зі start (не частіше ніж раз на 30 хв і не пізніше 22:00). */
export function spread(n: number, start: string): string[] {
  const s = t2m(start) < 0 ? 540 : t2m(start);
  const step = n > 1 ? Math.max(MIN_GAP_MIN, Math.min(180, Math.floor((1320 - s) / (n - 1)))) : 0;
  return Array.from({ length: n }, (_, i) => m2t(s + i * step));
}

/** Найближча публікація каналу за його розкладом (локальний час пристрою). */
export function nextPublication(c: Channel, now: Date = new Date()): string {
  const w = (now.getDay() + 6) % 7;
  const cm = now.getHours() * 60 + now.getMinutes();
  for (let k = 0; k < 8; k++) {
    const d = (w + k) % 7;
    if (!c.days[d]) continue;
    const times = c.schedule[d]
      .map(t2m)
      .filter((x) => x >= 0 && (k > 0 || x > cm))
      .sort((a, b) => a - b);
    if (times.length) return `${k === 0 ? 'Сьогодні' : k === 1 ? 'Завтра' : DAYS[d]} ${m2t(times[0])}`;
  }
  return '—';
}

/** «3» або «2–4», якщо в різні дні різна кількість відео. */
export function dailyCount(c: Channel): string {
  const a = c.schedule.filter((_, d) => c.days[d]).map((s) => s.length);
  if (!a.length) return '0';
  const lo = Math.min(...a);
  const hi = Math.max(...a);
  return lo === hi ? String(lo) : `${lo}–${hi}`;
}

/** Повертає текст помилки або порожній рядок, якщо налаштування коректні. */
export function validateChannel(c: Channel): string {
  if (!c.name.trim()) return 'Вкажіть назву проєкту';
  if (!(c.durationMin >= 1) || !(c.durationPref >= c.durationMin) || !(c.durationMax >= c.durationPref))
    return 'Тривалість: мінімум ≤ бажана ≤ максимум, усі значення від 1 хв';
  if (c.autoPublish && !c.days.some(Boolean)) return 'Оберіть хоча б один день публікації';
  for (let d = 0; d < 7; d++) {
    const s = c.schedule[d];
    if (c.autoPublish && c.days[d] && s.length === 0) return `${DAYS[d]}: день активний, але немає жодного часу публікації`;
    if (s.length > MAX_SLOTS) return `${DAYS[d]}: не більше ${MAX_SLOTS} публікацій на день`;
    const m = s.map(t2m);
    if (m.some((x) => x < 0)) return `${DAYS[d]}: некоректний формат часу`;
    m.sort((a, b) => a - b);
    for (let k = 1; k < m.length; k++) {
      if (m[k] === m[k - 1]) return `${DAYS[d]}: повторюється час ${m2t(m[k])}`;
      if (m[k] - m[k - 1] < MIN_GAP_MIN)
        return `${DAYS[d]}: між публікаціями має бути щонайменше ${MIN_GAP_MIN} хв (${m2t(m[k - 1])} і ${m2t(m[k])})`;
    }
  }
  return '';
}

export function sortSlots(c: Channel): Channel {
  return { ...c, schedule: c.schedule.map((s) => [...s].sort()) };
}
