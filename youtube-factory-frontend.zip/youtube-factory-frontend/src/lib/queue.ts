import type { Job, JobStatus } from '../types.ts';

export const STAGES = ['Сценарій', 'Зображення', 'Озвучка', 'Монтаж (FFmpeg)', 'Субтитри та музика', 'Перевірка якості'] as const;

export const stageOf = (progress: number): string =>
  progress >= 100 ? 'Завершено' : STAGES[Math.min(5, Math.floor(progress / 17))];

/** Один крок демонстраційної симуляції черги (поки немає бекенду). */
export function tick(jobs: Job[], rand: () => number = Math.random): Job[] {
  let next: Job[] = jobs.map((j) => {
    if (j.status !== 'run') return j;
    const progress = Math.min(100, j.progress + Math.ceil(rand() * 6));
    return { ...j, progress, status: (progress >= 100 ? 'done' : 'run') as JobStatus };
  });
  if (!next.some((j) => j.status === 'run')) {
    let idx = -1;
    next.forEach((j, i) => {
      if (j.status === 'wait') idx = i;
    });
    if (idx >= 0) next = next.map((j, i) => (i === idx ? { ...j, status: 'run' as JobStatus } : j));
  }
  return next;
}
