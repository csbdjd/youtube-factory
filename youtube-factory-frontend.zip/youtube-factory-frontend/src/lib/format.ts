import type { VideoCost } from '../types.ts';

export const money = (x: number): string => '$' + x.toFixed(2);
export const costOf = (v: VideoCost): number => v.script + v.image + v.voice;
