import { describe, expect, it } from 'vitest';
import { SEED_CHANNELS, newChannel } from '../data/demo.ts';
import { dailyCount, nextPublication, sortSlots, spread, validateChannel } from './schedule.ts';

const mon10 = new Date(2026, 10, 9, 10, 0); // понеділок 10:00

describe('розклад', () => {
  it('spread розставляє слоти з кроком не менше 30 хв', () => {
    expect(spread(3, '09:00')).toEqual(['09:00', '12:00', '15:00']);
    expect(spread(1, '18:00')).toEqual(['18:00']);
  });

  it('nextPublication бере найближчий слот', () => {
    const c = newChannel({ id: 'x', name: 'X', schedule: Array.from({ length: 7 }, () => ['09:00', '18:00']) });
    expect(nextPublication(c, mon10)).toBe('Сьогодні 18:00');
    expect(nextPublication(c, new Date(2026, 10, 9, 19, 0))).toBe('Завтра 09:00');
  });

  it('nextPublication пропускає вимкнені дні', () => {
    const c = newChannel({ id: 'x', name: 'X', days: [false, false, true, false, false, false, false] });
    expect(nextPublication(c, mon10)).toBe('Ср 09:00');
  });

  it('dailyCount показує діапазон, якщо дні різні', () => {
    const c = newChannel({ id: 'x', name: 'X' });
    expect(dailyCount(c)).toBe('3');
    c.schedule[1] = ['10:00'];
    expect(dailyCount(c)).toBe('1–3');
  });

  it('validateChannel знаходить помилки', () => {
    const ok = newChannel({ id: 'x', name: 'X', autoPublish: true });
    expect(validateChannel(ok)).toBe('');
    expect(validateChannel({ ...ok, name: ' ' })).toMatch(/назву/);
    expect(validateChannel({ ...ok, durationMin: 12, durationPref: 10 })).toMatch(/Тривалість/);
    const dup = structuredClone(ok);
    dup.schedule[0] = ['09:00', '09:00'];
    expect(validateChannel(dup)).toMatch(/повторюється/);
    const close = structuredClone(ok);
    close.schedule[2] = ['09:00', '09:20'];
    expect(validateChannel(close)).toMatch(/30 хв/);
    const bad = structuredClone(ok);
    bad.schedule[3] = ['9:00'];
    expect(validateChannel(bad)).toMatch(/формат/);
    const empty = structuredClone(ok);
    empty.schedule[4] = [];
    expect(validateChannel(empty)).toMatch(/немає жодного/);
  });

  it('налаштування каналів ізольовані одне від одного', () => {
    const a = structuredClone(SEED_CHANNELS[0]);
    a.schedule[0].push('23:00');
    expect(SEED_CHANNELS[0].schedule[0]).not.toContain('23:00');
    expect(SEED_CHANNELS[1].schedule[0]).not.toContain('23:00');
  });

  it('sortSlots сортує час', () => {
    const c = newChannel({ id: 'x', name: 'X', schedule: Array.from({ length: 7 }, () => ['18:00', '09:00']) });
    expect(sortSlots(c).schedule[0]).toEqual(['09:00', '18:00']);
  });
});
