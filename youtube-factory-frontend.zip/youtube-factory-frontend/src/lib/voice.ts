const SAMPLE: Record<string, string> = {
  uk: 'Привіт! Це тест голосу для вашого каналу.',
  en: 'Hello! This is a voice test for your channel.',
  pl: 'Cześć! To jest test głosu.',
  de: 'Hallo! Das ist ein Stimmtest.',
};
const BCP47: Record<string, string> = { uk: 'uk-UA', en: 'en-US', pl: 'pl-PL', de: 'de-DE' };

export const VOICES: ReadonlyArray<readonly [string, 'f' | 'm']> = [
  ['Олена', 'f'], ['Марія', 'f'], ['Софія', 'f'], ['Андрій', 'm'], ['Максим', 'm'], ['Богдан', 'm'],
];
export const LANGS: ReadonlyArray<readonly [string, string]> = [
  ['uk', 'Українська'], ['en', 'English'], ['pl', 'Polski'], ['de', 'Deutsch'],
];
export const TIMEZONES = ['Europe/Kyiv', 'Europe/Warsaw', 'Europe/Berlin', 'Europe/London', 'America/New_York'] as const;

/** Тест голосу вбудованим голосом браузера. Справжні AI-голоси з'являться після підключення провайдера. */
export function speakTest(lang: string, rate: number, volume0to100: number): boolean {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return false;
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(SAMPLE[lang] ?? SAMPLE.uk);
  u.lang = BCP47[lang] ?? 'uk-UA';
  u.rate = rate;
  u.volume = volume0to100 / 100;
  window.speechSynthesis.speak(u);
  return true;
}
