import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import type { Route } from './types';

export const ROUTES: readonly Route[] = ['home', 'channels', 'create', 'queue', 'publish', 'finance'];

function read(): Route {
  const h = window.location.hash.slice(1);
  return (ROUTES as readonly string[]).includes(h) ? (h as Route) : 'home';
}

interface Nav { route: Route; go: (r: Route) => void }
const NavContext = createContext<Nav>({ route: 'home', go: () => {} });

/** Мінімальний маршрутизатор на #hash (посилання на розділи працюють після оновлення сторінки). */
export function NavProvider({ children }: { children: ReactNode }) {
  const [route, setRoute] = useState<Route>(read);
  useEffect(() => {
    const on = () => setRoute(read());
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);
  const go = useCallback((r: Route) => {
    if (window.location.hash.slice(1) !== r) window.location.hash = r;
    setRoute(r);
    window.scrollTo(0, 0);
  }, []);
  const value = useMemo(() => ({ route, go }), [route, go]);
  return <NavContext.Provider value={value}>{children}</NavContext.Provider>;
}

export const useRoute = (): Route => useContext(NavContext).route;
export const useNav = (): ((r: Route) => void) => useContext(NavContext).go;
