export type Gender = 'f' | 'm';
export type JobStatus = 'run' | 'wait' | 'err' | 'done';
export type Route = 'home' | 'channels' | 'create' | 'queue' | 'publish' | 'finance';

/** Канал = окремий проєкт зі своїми налаштуваннями. Жодних спільних налаштувань між каналами немає. */
export interface Channel {
  id: string;
  name: string;
  emoji: string;
  gradient: string; // "#колір1,#колір2"
  theme: string;
  description: string;
  subscribers: string;
  monthlyViews: string;
  videos: number;
  growth: string;
  autoPublish: boolean;
  timezone: string; // 'auto' або назва IANA, напр. Europe/Kyiv
  days: boolean[]; // 7 елементів, 0 = Пн
  schedule: string[][]; // 7 списків часу "HH:MM"; кількість відео на день = довжина списку
  durationMin: number;
  durationPref: number;
  durationMax: number;
  voiceGender: Gender;
  voiceName: string;
  voiceLang: string;
  voiceSpeed: number;
  voiceVolume: number;
  googleId: string | null; // ID YouTube-каналу після підключення Google OAuth
  googleName: string;
}

export interface Job {
  id: string;
  title: string;
  channelId: string;
  progress: number;
  status: JobStatus;
  error?: string;
}

export interface VideoCost {
  title: string;
  channelId: string;
  script: number;
  image: number;
  voice: number;
}
