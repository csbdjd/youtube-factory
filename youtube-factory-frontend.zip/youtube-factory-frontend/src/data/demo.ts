// ДЕМОНСТРАЦІЙНІ ДАНІ. Використовуються, доки немає бекенду; на етапі 2 замінюються викликами API.
import type { Channel, Job, VideoCost } from '../types.ts';
import { spread } from '../lib/schedule.ts';

type NewChannel = Partial<Channel> & Pick<Channel, 'id' | 'name'>;

export function newChannel(p: NewChannel): Channel {
  const slots = spread(3, '09:00');
  return {
    emoji: '📺', gradient: '#ff2d2d,#7a0f16', theme: 'Без тематики', description: 'Опис ще не додано.',
    subscribers: '0', monthlyViews: '0', videos: 0, growth: '0%', autoPublish: false, timezone: 'auto',
    days: [true, true, true, true, true, true, true], schedule: Array.from({ length: 7 }, () => [...slots]),
    durationMin: 8, durationPref: 9, durationMax: 10, voiceGender: 'f', voiceName: 'Олена', voiceLang: 'uk',
    voiceSpeed: 1, voiceVolume: 80, googleId: null, googleName: '', ...p,
  };
}

const sched = (n: number, start: string): string[][] => Array.from({ length: 7 }, () => spread(n, start));

export const SEED_CHANNELS: Channel[] = [
  newChannel({ id: 'c1', name: 'Круті Факти', emoji: '🧠', gradient: '#ec4899,#8b5cf6', theme: 'Цікаві факти',
    description: 'Короткі відео з несподіваними фактами про світ.', subscribers: '72.4K', monthlyViews: '98K', videos: 46,
    growth: '+14%', autoPublish: true, schedule: sched(2, '18:00'), durationMin: 8, durationPref: 9, durationMax: 10 }),
  newChannel({ id: 'c2', name: 'Геймінг UA', emoji: '🎮', gradient: '#3b82f6,#1e3a8a', theme: 'Ігри',
    description: 'Огляди, новини та добірки ігор українською.', subscribers: '48.7K', monthlyViews: '61K', videos: 38,
    growth: '+11%', autoPublish: true, schedule: sched(1, '20:00'), durationMin: 10, durationPref: 12, durationMax: 15,
    voiceGender: 'm', voiceName: 'Андрій' }),
  newChannel({ id: 'c3', name: 'Світ Технологій', emoji: '💻', gradient: '#06b6d4,#1e40af', theme: 'Технології',
    description: 'Гаджети, штучний інтелект і новинки індустрії.', subscribers: '32.1K', monthlyViews: '44K', videos: 27,
    growth: '+9%', autoPublish: true, schedule: sched(1, '12:00'), durationMin: 6, durationPref: 7, durationMax: 8,
    voiceGender: 'm', voiceName: 'Максим' }),
  newChannel({ id: 'c4', name: 'Цікава Історія', emoji: '🏛️', gradient: '#f59e0b,#92400e', theme: 'Історія',
    description: 'Події та постаті, про які мало хто знає.', subscribers: '28.9K', monthlyViews: '31K', videos: 21,
    growth: '+7%', autoPublish: false, schedule: sched(1, '19:00'), durationMin: 12, durationPref: 13, durationMax: 15 }),
  newChannel({ id: 'c5', name: 'Природа Планети', emoji: '🌿', gradient: '#22c55e,#14532d', theme: 'Природа',
    description: 'Тварини, пейзажі та дивовижні куточки Землі.', subscribers: '24.3K', monthlyViews: '27K', videos: 16,
    growth: '+6%', autoPublish: true, schedule: sched(1, '16:00'), durationMin: 8, durationPref: 9, durationMax: 10 }),
];

export const SEED_JOBS: Job[] = [
  { id: 'j1', title: '10 неймовірних фактів про котів', channelId: 'c1', progress: 78, status: 'run' },
  { id: 'j2', title: 'Таємниці космосу, які вражають', channelId: 'c1', progress: 34, status: 'run' },
  { id: 'j3', title: 'Найкращі авто 2026 року', channelId: 'c3', progress: 0, status: 'wait' },
  { id: 'j4', title: 'Як працює нейромережа за 5 хвилин', channelId: 'c3', progress: 61, status: 'err',
    error: 'Помилка озвучки: перевищено ліміт запитів. Повторіть запуск.' },
  { id: 'j5', title: 'Загублені міста Давнього світу', channelId: 'c4', progress: 100, status: 'done' },
];

const vc = (title: string, channelId: string, script: number, image: number, voice: number): VideoCost =>
  ({ title, channelId, script, image, voice });

export const SEED_COSTS: VideoCost[] = [
  vc('10 фактів про котів', 'c1', 0.03, 0.62, 0.38), vc('Таємниці космосу', 'c1', 0.03, 0.7, 0.41),
  vc('Топ ігор осені', 'c2', 0.02, 0.55, 0.33), vc('Нові смартфони', 'c3', 0.02, 0.48, 0.3),
  vc('Історія Риму', 'c4', 0.04, 0.8, 0.52), vc('Дика Африка', 'c5', 0.03, 0.66, 0.36),
  vc('Як працює Wi‑Fi', 'c3', 0.02, 0.44, 0.28), vc('Скарби піратів', 'c4', 0.04, 0.74, 0.47),
];

export const PRODUCTION_14D = {
  created: [4, 5, 3, 6, 5, 7, 6, 5, 6, 8, 7, 6, 9, 8],
  published: [3, 4, 3, 5, 5, 6, 5, 4, 6, 7, 6, 5, 8, 7],
};
export const SYSTEM_STATUS = { online: true, cpu: 23, ram: 36, disk: 42 };
