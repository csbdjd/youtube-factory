import type { ReactNode } from 'react';

export function Modal({ onClose, wide, children }: { onClose: () => void; wide?: boolean; children: ReactNode }) {
  return (
    <div id="md" className={'s' + (wide ? ' w' : '')} onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div role="dialog" aria-modal="true">{children}</div>
    </div>
  );
}
