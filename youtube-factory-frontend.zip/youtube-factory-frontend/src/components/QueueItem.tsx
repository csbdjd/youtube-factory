import { stageOf } from '../lib/queue';
import { useStore } from '../store/AppStore';
import type { Job } from '../types';
import { Icon, JobPill } from './ui';

export function QueueItem({ job, full }: { job: Job; full?: boolean }) {
  const { channels, retryJob } = useStore();
  const channel = channels.find((c) => c.id === job.channelId);
  const tone = job.status === 'err' ? 'er' : job.status === 'done' ? 'ok' : '';
  return (
    <div className="row" style={{ alignItems: 'flex-start' }}>
      <div className="grow">
        <div className="ttl">
          <div className="t" style={{ whiteSpace: 'normal' }}>{job.title}</div>
          <JobPill status={job.status} />
        </div>
        <div className="m">{channel?.name ?? '—'} · {job.status === 'wait' ? 'Очікує запуску' : stageOf(job.progress)}</div>
        <div className={'prog ' + tone}><i style={{ width: `${job.progress}%` }} /></div>
        {job.status === 'err' && (
          <>
            <div className="m" style={{ color: '#ff7b7b', marginTop: 8 }}>{job.error}</div>
            <button type="button" className="btn sm" style={{ marginTop: 8 }} onClick={() => retryJob(job.id)}>
              <Icon name="redo" />Запустити знову
            </button>
          </>
        )}
        {full && job.status === 'wait' && <div className="m" style={{ marginTop: 6 }}>Позиція в черзі: наступна</div>}
      </div>
      <div style={{ fontWeight: 800, minWidth: 42, textAlign: 'right' }}>{job.progress}%</div>
    </div>
  );
}
