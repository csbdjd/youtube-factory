import type { CSSProperties, ReactNode } from 'react';
import type { Channel, JobStatus } from '../types';

const PATHS = {
  home: 'M3 11l9-8 9 8M5 10v10h14V10',
  tv: 'M3 6h18v12H3zM10 9l5 3-5 3z',
  cam: 'M3 7h12v10H3zM15 11l6-3v8l-6-3z',
  list: 'M4 6h16M4 12h16M4 18h10',
  up: 'M12 19V5M5 12l7-7 7 7',
  usd: 'M12 2v20M17 6H9.5a3 3 0 000 6h5a3 3 0 010 6H6',
  plus: 'M12 5v14M5 12h14',
  redo: 'M3 12a9 9 0 109-9M3 4v5h5',
  bolt: 'M13 2L4 14h7l-1 8 9-12h-7z',
} as const;
export type IconName = keyof typeof PATHS;

export function Icon({ name }: { name: IconName }) {
  return (
    <svg className="i" viewBox="0 0 24 24" aria-hidden="true">
      <path d={PATHS[name]} />
    </svg>
  );
}

export function Switch({ on, onChange, label }: { on: boolean; onChange: () => void; label: string }) {
  return <button type="button" className={'sw' + (on ? ' on' : '')} onClick={onChange} aria-label={label} aria-pressed={on} />;
}

export type Tone = 'ok' | 'wn' | 'er' | 'bl' | '';
export function Pill({ tone = '', children }: { tone?: Tone; children: ReactNode }) {
  return <span className={'pill' + (tone ? ' ' + tone : '')}>{children}</span>;
}

const JOB_PILL: Record<JobStatus, [Tone, string]> = { run: ['bl', 'Виконується'], wait: ['', 'Очікує'], err: ['er', 'Помилка'], done: ['ok', 'Готово'] };
export function JobPill({ status }: { status: JobStatus }) {
  const [tone, label] = JOB_PILL[status];
  return <Pill tone={tone}>{label}</Pill>;
}

export function Avatar({ channel, size }: { channel: Channel; size?: number }) {
  const style: CSSProperties = { background: `linear-gradient(135deg,${channel.gradient})`, ...(size ? { width: size, height: size } : {}) };
  return <div className="av" style={style}>{channel.emoji}</div>;
}

export function PageHead({ title, sub, right }: { title: string; sub: string; right?: ReactNode }) {
  return (
    <div className="top">
      <div>
        <h1>{title}</h1>
        <div className="sub">{sub}</div>
      </div>
      {right}
    </div>
  );
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="fld">
      <label className="f">{label}</label>
      {children}
    </div>
  );
}

export function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="card" style={{ marginBottom: 12, background: 'var(--p2)' }}>
      <h3>{title}</h3>
      {children}
    </div>
  );
}
