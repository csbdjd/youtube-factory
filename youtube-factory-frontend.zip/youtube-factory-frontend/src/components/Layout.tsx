import { SYSTEM_STATUS } from '../data/demo';
import { useNav, useRoute } from '../router';
import type { Route } from '../types';
import { Icon } from './ui';
import type { IconName } from './ui';

const NAV: ReadonlyArray<{ id: Route; label: string; short: string; icon: IconName }> = [
  { id: 'home', label: 'Головна', short: 'Головна', icon: 'home' },
  { id: 'channels', label: 'Мої канали', short: 'Канали', icon: 'tv' },
  { id: 'create', label: 'Створення', short: 'Створити', icon: 'cam' },
  { id: 'queue', label: 'Черга', short: 'Черга', icon: 'list' },
  { id: 'publish', label: 'Публікація', short: 'Вихід', icon: 'up' },
  { id: 'finance', label: 'Фінанси', short: 'Фінанси', icon: 'usd' },
];

function Meter({ label, value }: { label: string; value: number }) {
  return (
    <>
      <div className="m" style={{ margin: '8px 0 4px' }}>{label} {value}%</div>
      <div className="bar"><i style={{ width: `${value}%` }} /></div>
    </>
  );
}

export function Sidebar() {
  const route = useRoute();
  const go = useNav();
  return (
    <aside>
      <div className="logo">
        <b><i /></b>
        <div>YouTube Factory<small>Auto Content Creator</small></div>
      </div>
      <div className="srv">
        <div><span className="dot" />Сервер онлайн</div>
        <Meter label="CPU" value={SYSTEM_STATUS.cpu} />
        <Meter label="RAM" value={SYSTEM_STATUS.ram} />
        <Meter label="Диск" value={SYSTEM_STATUS.disk} />
      </div>
      <div id="sn">
        {NAV.map((n) => (
          <button key={n.id} type="button" className={'nb' + (n.id === route ? ' on' : '')} onClick={() => go(n.id)}>
            <Icon name={n.icon} />{n.label}
          </button>
        ))}
      </div>
    </aside>
  );
}

export function BottomNav() {
  const route = useRoute();
  const go = useNav();
  return (
    <nav className="bt" aria-label="Навігація">
      {NAV.map((n) => (
        <button key={n.id} type="button" className={n.id === route ? 'on' : ''} onClick={() => go(n.id)}>
          <Icon name={n.icon} />{n.short}
        </button>
      ))}
    </nav>
  );
}
