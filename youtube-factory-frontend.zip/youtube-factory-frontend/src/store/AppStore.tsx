import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import { SEED_CHANNELS, SEED_COSTS, SEED_JOBS } from '../data/demo';
import { tick } from '../lib/queue';
import type { Channel, Job, VideoCost } from '../types';

const KEY = 'yf_channels_v2';

function load(): Channel[] {
  try {
    const raw = window.localStorage.getItem(KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Channel[];
      if (Array.isArray(parsed) && parsed.length) return parsed;
    }
  } catch {
    /* пошкоджені дані — повертаємось до початкових */
  }
  return SEED_CHANNELS;
}

const uid = (): string => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

interface Store {
  channels: Channel[];
  jobs: Job[];
  costs: VideoCost[];
  toggleAuto: (id: string) => boolean; // повертає новий стан
  saveChannel: (c: Channel) => void;
  addChannel: (c: Channel) => void;
  addJob: (title: string, channelId: string) => void;
  retryJob: (id: string) => void;
}

const StoreContext = createContext<Store | null>(null);

/**
 * Єдине місце, де живуть дані застосунку. Зараз це демонстраційне сховище (канали зберігаються в localStorage браузера).
 * На етапі 2 реалізація замінюється викликами backend API без змін у компонентах.
 */
export function StoreProvider({ children }: { children: ReactNode }) {
  const [channels, setChannels] = useState<Channel[]>(load);
  const [jobs, setJobs] = useState<Job[]>(SEED_JOBS);

  useEffect(() => {
    try {
      window.localStorage.setItem(KEY, JSON.stringify(channels));
    } catch {
      /* сховище недоступне */
    }
  }, [channels]);

  useEffect(() => {
    const t = window.setInterval(() => setJobs((j) => tick(j)), 1500);
    return () => window.clearInterval(t);
  }, []);

  const toggleAuto = useCallback(
    (id: string) => {
      const cur = channels.find((c) => c.id === id);
      const next = !(cur?.autoPublish ?? false);
      setChannels((cs) => cs.map((c) => (c.id === id ? { ...c, autoPublish: next } : c)));
      return next;
    },
    [channels],
  );
  const saveChannel = useCallback((c: Channel) => setChannels((cs) => cs.map((x) => (x.id === c.id ? c : x))), []);
  const addChannel = useCallback((c: Channel) => setChannels((cs) => [...cs, c]), []);
  const addJob = useCallback(
    (title: string, channelId: string) =>
      setJobs((js) => [{ id: uid(), title, channelId, progress: 0, status: 'wait' }, ...js]),
    [],
  );
  const retryJob = useCallback(
    (id: string) =>
      setJobs((js) =>
        js.map((j) => (j.id === id ? { ...j, status: 'run', progress: Math.max(0, j.progress - 10), error: undefined } : j)),
      ),
    [],
  );

  const value = useMemo<Store>(
    () => ({ channels, jobs, costs: SEED_COSTS, toggleAuto, saveChannel, addChannel, addJob, retryJob }),
    [channels, jobs, toggleAuto, saveChannel, addChannel, addJob, retryJob],
  );
  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore(): Store {
  const s = useContext(StoreContext);
  if (!s) throw new Error('useStore потрібно викликати всередині StoreProvider');
  return s;
}

export { uid };
