import react from '@vitejs/plugin-react';
import { defineConfig } from 'vitest/config';

// У розробці запити /api проксуються на майбутній бекенд (FastAPI на :8000).
export default defineConfig({
  plugins: [react()],
  server: { host: true, port: 5173, proxy: { '/api': 'http://localhost:8000' } },
  build: { outDir: 'dist' },
  test: { environment: 'node', include: ['src/**/*.test.ts'] },
});
